<!-- john Fri Dec 17 17:35:16 PDT 2023 -->
# 1031_Delivery

This repo contains code and scripts for working with robotic
control data for animatronics.  It is designed to work with
board designs created by Bill Douglas and available for
download with this repo at [Pico/Hardware](Pico/Hardware/).

This codebase contains an application, Hauntimator, for creating control
channel data for directing the animatronics and code for
executing on a Raspberry Pi Pico for performing the animations.
The Hauntimator application is intended to be board-agnostic so
users may develop code for different processors such as 
Arduino or other Raspberry Pi versions.

It also contains a utility application, joysticking.py, for recording
joystick actions into Hauntimator channels.  For Pololu Maestro
animation controller users, it includes the Maestro_Animator.py
application forplaying back animations via Maestros.

***

## Description

The general procedure for working with animatronics is to
create control channels that may be synced to an audio stream.
The channels may act as step functions, linear paths, and
smoothed or spline paths.  Each channel is linked to a single
control on a controller.

![Hauntimator Main Window](docs/images/allpanes.png)

Once the control channels have been created and validated to be
synchronized with the audio, they are installed on the control
hardware in flash memory or on an SD card.  Then the software
on the control board runs to perform the animations and play 
the audio.

***

## Installation

### Linux and MacOS

If you are reading this, you have already downloaded and unzipped the
release files.  To enable the applications, run the install script in
the same directory as this README.  Run it in a terminal window as it
asks if you want desktop icons created.  Select anything other than 'y'
if you prefer command line operation as I do.

Note that on a Mac, it is difficult to create executable desktop icons
due to their security setup.  In order for the install script to be able
to create the desktop icons in working condition, the user needs to
create an Automator template to use.  To do this, run the Automator
application, shipped with every Mac, from the Applications folder.  On
the first page, select Application.  Then select "Run Shell Script"
from the long list of possible actions by double clicking on it.  Then
Save it on the desktop as Untitled.  The install script will use this
as a template to create executable icons on the desktop.  Once the
icons are created, the Untitled template may be deleted.  Don't though
as you may download versions and upgrades in the future and may need to
recreate the shortcuts.

The Hauntimator and joysticking applications generally work best
when they are able to communicate with and control the animatronics
controller hardware.  This requires that the user run tools that
access the Pico over the USB serial port.  This requires system
permissions such that the user is in the dialout group.  Check with:

groups

If the list that is output includes dialout you are golden.  If not,
you have to add yourself to the dialout group with this command:

sudo usermod -aG dialout `whoami`

Then you have to at least log out and back in or restart the system.

Once you are in the dialout group, proceed with the following steps to install
the embedded software into the flash memory of the Raspberry Pi
Pico (currently the only supported controller):

- Plug a USB cable into the Pico board and this PC
- Install an appropriate MicroPython image on the board (see Pico/README)
- cd to the Pico/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pico/lib/README)
- cd to the Pico directory
- run "do_install" to install all the embedded software on the Pico (see Pico/README)
    and link to the Pico libraries


Note that it is not necessary for Hauntimator and joysticking to
communicate with the Pico.  It is perfectly possible to create
animation control files, write them to an SD card on the PC, and 
then transfer the SD card to the controller.  However, a direct
connection provides for more rapid iterations when developing and
testing an animation.

If you are using Pololu Maestros, the steps are similar but different.  In that case,
do this:

- cd to the Pololu/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pololu/lib/README)
- cd to the Pololu directory
- run "do_install" to link to the Pololu libraries

### Windows

A Windows version of the install script is now included and is named windo_install.bat.
It performs most of the same tasks as the linux version but creates batch files
in the install directory instead of linux scripts.  It also optionally
creates desktop shortcuts with nice icons.

This one really only makes a symbolic link in the installation/src directory to
installation/Pololu/commlib.py.  Note that this step, and only this step, requires
Administrator privileges because heaven forbid that someone would want to create
a symbolic link.

***

## Details

Both Hauntimator and joysticking have available Help accessible via
the Help menu.  Hopefully, it is mostly accurate and up-to-date.

### Hauntimator

Hauntimator is the visual user interface for creating and editing the
control channels.  It displays a stack of channels, typically with 
audio at the top, in which all channels display the same time range.
During audio playback, a green bar moves across all channels so that
the user may visually align behaviors between channels and the audio
track.

Step functions hold a continuous value for a time and then
switch to a different value.  A subset of these are only 0 or 1
and control on/off devices like lights.  Linear paths use a
set of knots specifying some values at certain times and the
path is linearly interpolated between knots.  Spline paths use
a similar set of knots but apply Lagrange interpolation between the
knots for a smoother motion of the controlled device.

Channel data may be exported to a CSV file to be transferred to an
external hardware controller.  In addition, a pipe may be used to
directly signal the controller from the system while it runs
Hauntimator.

### joysticking

joysticking is a GUI application for recording joystick actions into
Hauntimator channels.  It reads an animation file created by Hauntimator
and provides an interface for mapping joystick axes and buttons to
channels in the animation.  Then it enables recording of the joystick
actions into those channels, playback of the channels, and saving of
the animation file for Hauntimator to read.

### Pico

This installation includes files for using a Raspberry Pi Pico or
clone for your animatronics controller.  The provided software is in 
the Pico directory.  See the README there for more details.

In the Pico part of the repo there is a file named commlib.py.  This
is the interface library for Hauntimator to talk to the hardware.
In order for Hauntimator to load the right commlib, there should be a
symbolic link in the 1031_Delivery directory to the appropriate
commlib.py file to support users developing controllers with other
hardware or programming languages.  commlib.py has the purpose of
decoupling Hauntimator from the hardware specifics.  Note that the
do_install script used to install the embedded software on the Pico
creates this link so you don't have to do it explicitly.

Hauntimator's direct communication with the hardware is optional and
Hauntimator will function without commlib.  In this case, the audio and
control files will need to be transferred to the hardware via rshell,
thonny, direct copy to SD card, or other mechanism.  Hauntimator can
output the CSV control files locally for separate transfer and the
audio files must already exist on the system.

### Pololu

This installation also includes files for using Pololu Maestro
animation controllers.  The provided software is in the Pololu
directory.  See the README there for more details.

In the Pololu subdirectory, there is a file named commlib.py.  This
is the interface library for Hauntimator.py to talk to the hardware.
In order for Hauntimator to load the right commlib, there should be a
symbolic link in the Animatronics directory to the appropriate
commlib.py file to support users developing controllers with other
hardware or programming languages.  commlib.py has the purpose of
decoupling Hauntimator from the hardware specifics.

Hauntimator's direct communication with the hardware is optional and
somewhat limited because the hardware does not in fact store the
animations as the the Pico-based Animator board does.  The animations
are stored in the local filesystem and another application,
Maestro_Animator is used to play them via its Maestro interface.

### Pico or Pololu

Your choice of Pico or Pololu is based entirely on what animation
hardware you are using.  Build the Pico-based Animator from designs
in this repo and use Pico.  Buy some Pololu Maestros and use Pololu.
The choice is made by a symbolic link in the src directory.  If this
link points to the Pico side then the Pico libraries are used.  If it
points to the Pololu side then Pololu libraries are used.  This link
is created on linux and MacOS via the do_install script run either in
the Pico directory or the Pololu directory.  This link is created on
Windows 11 via the windo_install.bat file run in either the Pico or
Pololu directory.  Note that on Windows, Administrator privileges
are required to make that link and thus to run the windo_install.bat
script.  Note that the windo_install.bat script is currently only 
available for Pololu as it is unlikely that anyone has yet built the
Animator board.  If you have done so and really want the Pico script
converted, let us know so we can prioritize it.

## Caveat

This package is intended to support creating animations and running
them on the type of board specified in the Pico/Hardware section of the
repo.  Due to the nature of the embedded software, it is quite possible
to modify any of the code that runs on the Pico.  However, there is no
mechanism for pushing changes back to the repo.  Similarly, the main
desktop application source code is available (in the src directory)
but there is no mechanism for pushing changes back to the repo.  If
you wish to do this, follow the Developers instructions on the repo's
README.

New team members are welcome.
Drop me a line at SW dot 1031 dot Systems at gmail dot com.  Note that I am generally
clueless about running a repo with more than one developer so a repo
manager would be extremely useful.  Also, I have tried to include a lot
of documentation.  As changes are made, in particular Windows support,
I know some things have gotten behind.  Anyone who has the desire to
update documentation is welcome! :)

This software is made available for use under the GNU General Public License (GPL).
A copy of this license is available within the repository for this software and is
included herein by reference.

***

Copyright 2025 John R. Wright, William R. Douglas - 1031_Systems
