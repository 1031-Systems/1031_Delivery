<!-- john Fri Dec 17 17:35:16 PDT 2023 -->
# 1031_Delivery

This repo contains code and scripts for working with servo and digital
control data for animatronics.  It is designed to work with
board designs created by Bill Douglas and installed software/firmware
created by John Wright, both available for
download with this repo at [Pico/Hardware](Pico/Hardware/).
As an alternative to hardware fabrication, Maestro animation
controllers from Pololu are also supported.

This codebase contains an application, Hauntimator, for creating control
channel data for directing the animatronics and code for
executing on a Raspberry Pi Pico for performing the animations.
The Hauntimator application is intended to be board-agnostic so
users may develop code for different processors such as 
Arduino or other Raspberry Pi versions.

It also contains a utility application, joysticking.py, for recording
joystick actions into Hauntimator channels.  For Pololu Maestro
animation controller users, it includes the Maestro_Animator.py
application for playing back animations via Maestros.

***

## Description

The general procedure for working with animatronics is to
create control channels that may be synced to an audio stream.
The channels may act as step functions, linear paths, and
smoothed or spline paths.  Each channel is linked to a single
control channel on a controller.

![Hauntimator Main Window](docs/images/allpanes.png)

Once the control channels have been created and validated to be
synchronized with the audio, they are installed on the control
hardware in flash memory or on an SD card.  Then the software
on the control board runs to perform the animations and play 
the audio.

***

## Before You Install

You may upset your anti-virus tools running the install commands even though
we have tried to use AV-friendly methods.  If you have problems you may either
disable your AV software or run the steps below manually.  bitdefender, at least,
seems to have no problems when everything is run manually but sometimes complains
on the quick install methods.  Or you can disable first and then install.  Your
choice.  We recommend disabling your AV software during the install.

These tools require python3 and the python venv module for setting up and using
virtual environments.  Generally, venv comes with python but on some systems
may need to be installed separately.  The system has been tested with python3.9 
and python 3.11.  It should be pretty flexible about exactly which version you
have installed but might be unhappy with very old or very new versions.

On a linux-based system, you need to be a member of the dialout group.  See the
Linux/MacOS installation guide below for more details.

If using a Raspberry Pi Pico system, you will need to have Micropython installed
on the Pico prior to installing our software.  Details on how to do this are all
over the interweb with some notes in the Pico/README file.

If using Pololu Maestro animation controllers, you will need to have Pololu's
MaestroControlCenter available.  It doesn't have to be on the same system as
long as it is available to you somewhere.  More details are in the Pololu/README
file.

## Installation

Read the following sections for details on the installation process but
also read the Quick Install section to see if you can use the easy
method.

### Quick Install Option

Once you have downloaded and unzipped the appropriate release file, scripts are
available to aid the installation process.   These scripts do all the
below steps for either Pico or Pololu, except install MicroPython on the Pico and
install MaestroControlCenter for Pololu Maestros.  These
assume a default tabledefs configuration file.  Since most users will work on a 
single platform with a single type of animation controller, running the appropriate
install script is the easiest way to get going:

| OS | Controller | Script |
|------|------|------|
| linux/MacOS | Pico | 1031_Hauntimator/quickinstall_Pico |
| linux/MacOS | Pololu | 1031_Hauntimator/quickinstall_Pololu |
| Windows 11 | Pico | 1031_Hauntimator\\winquickinstall_Pico.bat |
| Windows 11 | Pololu | 1031_Hauntimator\\winquickinstall_Pololu.bat |

In general, all the above quick install scripts may be run from the command line
or by double-clicking from a file browser such as File Explorer on Windows.  Just
remember that where the unzipped directory is located is the install location.
It cannot be moved later and still have the desktop icons work.

To support multiple hardware types from
the same system, simply unzip the zip file again and run another quickinstall
script to support that additional hardware type.  Each installation changes the name
of 1031_Hauntimator to Pico_Hauntimator or Pololu_Hauntimator and creates desktop
shortcuts named Pico or Pololu for running the Hauntimator application for that
hardware.

[ TMI Warning - If you are wondering why we change the name of the 1031_Hauntimator directory,
it is because the desktop shortcuts contain a path to the executables.  These must be 
known when the shortcuts are created.  Then, if the directory name is not changed, any
additional hardware installations (e.g. supporting both Pico and Pololu) will simply
point at the same executables and everything gets confused.]

These quick install scripts only install the python tools.  When using a Pico-based
animation controller, it is also necessary to install a MicroPython image and then
all the MicroPython code into the Pico flash memory.  See the Pico/README for more
on installing MicroPython on the Pico.  Once that is done, the embedded code can be
installed.  There is one command to do this:

| OS | Script |
|------|------|
| linux/MacOS | Pico/Pico_install |
| Windows 11  | Pico\\winPicoinstall.bat |

### Linux and MacOS

If you are reading this, you have already downloaded and unzipped the
release files.  To enable the applications, run the install script in
the same directory as this README.  Run it in a terminal window as it
asks if you want desktop icons created.  Select anything other than 'y'
if you prefer command line operation as I do.

Hauntimator and other applications generally work best
when they are able to communicate with and control the animatronics
controller.  This requires that the user run tools that
access the controller hardware over the USB serial port.  This requires system
permissions such that the user is in the dialout group.  Check with:

groups

If the list that is output includes dialout you are golden.  If not,
you have to add yourself to the dialout group with this command:

sudo usermod -aG dialout `whoami`

Then you have to at least log out and back in or restart the system.

Once you are in the dialout group, proceed with the following steps to install
the embedded software into the flash memory of the Raspberry Pi
Pico:

- Plug a USB cable into the Pico board and this PC
- Install an appropriate MicroPython image on the board (see Pico/README)
- cd to the Pico/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pico/lib/README)
- cd to the Pico directory
- run "do_install" to link to the Pico libraries
- run "Pico_install" to install all the embedded software on the Pico (see Pico/README)

Note that it is not necessary for Hauntimator and joysticking to
communicate with the Pico.  It is perfectly possible to create
animation control files, write them to an SD card on the PC, and 
then transfer the SD card to the controller.  However, a direct
connection provides for more rapid iterations when developing and
testing an animation.

If you are using Pololu Maestros, the steps are similar but different.  In that case,
do this:

- cd to the Pololu/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pololu/lib/README)
- cd to the Pololu directory
- run "do_install" to link to the Pololu libraries

To use the Maestro controllers, they must be configured for your system.  This
is done with the MaestroControlCenter application available from Pololu.  You
will need this application so follow the directions at:
https://www.pololu.com/product/1350/resources

### Windows

A Windows version of the install script is now included and is named wininstall.bat.
It performs most of the same tasks as the linux version but creates batch files
in the install directory instead of linux scripts.  It also optionally
creates desktop shortcuts with nice icons.

Once you have run wininstall.bat, proceed with the following steps to install
the embedded software into the flash memory of the Raspberry Pi
Pico:

- Plug a USB cable into the Pico board and this PC
- Install an appropriate MicroPython image on the board (see Pico/README)
- cd to the Pico/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pico/lib/README)
- cd to the Pico directory
- run "windo_install.bat" to link to the Pico libraries
- run "winPicoinstall.bat" to install all the embedded software on the Pico (see Pico/README)

Note that it is not necessary for Hauntimator and joysticking to
communicate with the Pico.  It is perfectly possible to create
animation control files, write them to an SD card on the PC, and 
then transfer the SD card to the controller.  However, a direct
connection provides for more rapid iterations when developing and
testing an animation.

If you are using Pololu Maestros, the steps are similar but different.  In that case,
do this:

- cd to the Pololu/lib directory
- copy tabledefs_template to tabledefs and edit it as needed (see Pololu/lib/README)
- cd to the Pololu directory
- run "windo_install.bat" to link to the Pololu libraries

To use the Maestro controllers, they must be configured for your system.  This
is done with the MaestroControlCenter application available from Pololu.  You
will need this application so follow the directions at:
https://www.pololu.com/product/1350/resources

***

## Details

Both Hauntimator and joysticking have available Help accessible via
the Help menu.  Hopefully, it is mostly accurate and up-to-date.

### Hauntimator

Hauntimator is the visual user interface for creating and editing the
control channels.  It displays a stack of channels, typically with 
audio at the top, in which all channels display the same time range.
During audio playback, a green bar moves across all channels so that
the user may visually align behaviors between channels and the audio
track.

Step functions hold a continuous value for a time and then
switch to a different value.  A subset of these are only 0 or 1
and control on/off devices like lights.  Linear paths use a
set of knots specifying some values at certain times and the
path is linearly interpolated between knots.  Spline paths use
a similar set of knots but apply Lagrange interpolation between the
knots for a smoother motion of the controlled device.

Channel data may be exported to a CSV file to be transferred to an
external hardware controller.  In addition, a pipe may be used to
directly signal the controller from the system while it runs
Hauntimator.

### joysticking

joysticking is a GUI application for recording joystick actions into
Hauntimator channels.  It reads an animation file created by Hauntimator
and provides an interface for mapping joystick axes and buttons to
channels in the animation.  Then it enables recording of the joystick
actions into those channels, playback of the channels, and saving of
the animation file for Hauntimator to read.

### Pico

This installation includes files for using a Raspberry Pi Pico or
clone for your animatronics controller.  The provided software is in 
the Pico directory.  See the README there for more details.

In the Pico part of the repo there is a file named commlib.py.  This
is the interface library for Hauntimator to talk to the hardware.
In order for Hauntimator to load the right commlib, there must be a
small python file in the src directory named pointer.py that points
to the appropriate controller installation and commlib.py.
commlib.py has the purpose of
decoupling Hauntimator from the hardware specifics.  Note that the
do_install script used to install the embedded software on the Pico
creates the pointer.py file so you don't have to do it explicitly.

Hauntimator's direct communication with the hardware is optional and
Hauntimator will function without commlib.  In this case, the audio and
control files will need to be transferred to the hardware via rshell,
thonny, direct copy to SD card, or other mechanism.  Hauntimator can
output the CSV control files locally for separate transfer and the
audio files must already exist on the system.

### Pololu

This installation also includes files for using Pololu Maestro
animation controllers.  The provided software is in the Pololu
directory.  See the README there for more details.

In the Pololu subdirectory, there is a file named commlib.py.  This
is the interface library for Hauntimator.py to talk to the hardware.
In order for Hauntimator to load the right commlib, there must be a
small python file in the src directory named pointer.py that points
to the appropriate controller installation and commlib.py.
commlib.py has the purpose of
decoupling Hauntimator from the hardware specifics.  Note that the
do_install script 
creates the pointer.py file so you don't have to do it explicitly.

Hauntimator's direct communication with the hardware is optional and
somewhat limited because the hardware does not in fact store the
animations as the the Pico-based Animator board does.  The animations
are stored in the local filesystem and another application,
Maestro_Animator is used to play them via its Maestro interface.

### Pico or Pololu

Your choice of Pico or Pololu is based entirely on what animation
hardware you are using.  Build the Pico-based Animator from designs
in this repo and use Pico.  Buy some Pololu Maestros and use Pololu.
The choice is made by a python file in the src directory.  If this
file points to the Pico side then the Pico libraries are used.  If it
points to the Pololu side then Pololu libraries are used.  This file
is created on linux and MacOS via the do_install script run either in
the Pico directory or the Pololu directory.  This file is created on
Windows 11 via the windo_install.bat file run in either the Pico or
Pololu directory.  

### Pico AND Pololu

If you wish to use and support both Pico and Maestro animation
controllers there are two ways to do it.  You can run the quickinstall
script for both Pico and Pololu and create two separate installations
and sets of desktop icons.  There may be one or two rare interactions
that might cause trouble but this is generally safe, quick, and easy.
The other way is to create a neutral installation via the step-by-step
installation procedure above.  You will need to edit the tabledefs file
under each type of controller and run do_install (windo_install.bat)
in each controller directory.  Running the desktop Hauntimator will
then operate the last one installed.  To switch, run usePico (winUsePico.bat)
in the Pico directory to use Pico or run usePololu (winUsePololu.bat)
in the Pololu directory to use Pololu.  Only one type of controller
can be operated at a time with this but there is only a single
installation.  To identify which controller is currently in use,
look at the top of the Hauntimator window.  The controller type should
be present in the window title.

## Caveat

This package is intended to support creating animations and running
them on the type of board specified in the Pico/Hardware section of the
repo.  Due to the nature of the embedded software, it is quite possible
to modify any of the code that runs on the Pico.  However, there is no
mechanism for pushing changes back to the repo.  Similarly, the main
desktop application source code is available (in the src directory)
but there is no mechanism for pushing changes back to the repo.  If
you wish to do this, follow the Developers instructions on the repo's
README.

New team members are welcome.
Drop me a line at SW dot 1031 dot Systems at gmail dot com.  Note that I am generally
clueless about running a repo with more than one developer so a repo
manager would be extremely useful.  Also, I have tried to include a lot
of documentation.  As changes are made, in particular Windows support,
I know some things have gotten behind.  Anyone who has the desire to
update documentation is welcome! :)

This software is made available for use under the GNU General Public License (GPL).
A copy of this license is available within the repository for this software and is
included herein by reference.

***

Copyright 2026 John R. Wright, William R. Douglas - 1031_Systems
